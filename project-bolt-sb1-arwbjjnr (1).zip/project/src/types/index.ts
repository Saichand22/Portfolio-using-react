export interface Skill {
  name: string;
  icon: string;
}

export interface Project {
  title: string;
  description: string;
  technologies: string[];
  image: string;
  liveLink: string;
  githubLink: string;
}

export interface Certification {
  title: string;
  issuer: string;
  date: string;
  certificateLink: string;
}

export interface Education {
  degree: string;
  institution: string;
  location: string;
  period: string;
  grade: string;
}

export interface PersonalInfo {
  name: string;
  title: string;
  email: string;
  phone: string;
  github: string;
  linkedin: string;
  resumeLink: string;
}