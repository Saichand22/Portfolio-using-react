import React, { useState, useEffect } from 'react';
import { Menu, X, Download } from 'lucide-react';
import { personalInfo } from '../data/data';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };

  return (
    <header 
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        scrolled ? 'bg-white shadow-md py-3' : 'bg-transparent py-5'
      }`}
    >
      <div className="container mx-auto px-4 flex justify-between items-center">
        <div>
          <h1 className={`font-bold text-xl transition-all duration-300 ${
            scrolled ? 'text-gray-800' : 'text-white'
          }`}>
            Sai Chand
          </h1>
        </div>
        
        <div className="hidden md:flex items-center space-x-8">
          <nav>
            <ul className="flex space-x-6">
              {['home', 'skills', 'projects', 'certifications', 'education', 'contact'].map((item) => (
                <li key={item}>
                  <button 
                    onClick={() => scrollToSection(item)}
                    className={`capitalize transition-all duration-300 hover:text-blue-600 ${
                      scrolled ? 'text-gray-800' : 'text-white'
                    }`}
                  >
                    {item}
                  </button>
                </li>
              ))}
            </ul>
          </nav>
          <a 
            href={personalInfo.resumeLink} 
            target="_blank" 
            rel="noopener noreferrer"
            className={`flex items-center space-x-1 px-4 py-2 rounded-md border transition-all duration-300 ${
              scrolled 
                ? 'border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white' 
                : 'border-white text-white hover:bg-white hover:text-blue-600'
            }`}
          >
            <Download size={16} />
            <span>Resume</span>
          </a>
        </div>
        
        <button 
          className={`md:hidden transition-all duration-300 ${scrolled ? 'text-gray-800' : 'text-white'}`}
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>
      
      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-white shadow-md">
          <nav className="container mx-auto px-4 py-4">
            <ul className="space-y-4">
              {['home', 'skills', 'projects', 'certifications', 'education', 'contact'].map((item) => (
                <li key={item}>
                  <button 
                    onClick={() => scrollToSection(item)}
                    className="block w-full text-left capitalize text-gray-800 hover:text-blue-600 py-2"
                  >
                    {item}
                  </button>
                </li>
              ))}
              <li>
                <a 
                  href={personalInfo.resumeLink} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center space-x-1 mt-4 text-blue-600 hover:underline"
                >
                  <Download size={16} />
                  <span>Download Resume</span>
                </a>
              </li>
            </ul>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;