import React from 'react';
import { projects } from '../data/data';
import ProjectCard from './ProjectCard';

const Projects: React.FC = () => {
  return (
    <section id="projects" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">My Projects</h2>
          <div className="w-20 h-1 bg-blue-600 mx-auto mb-6"></div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Here are some of the projects I've worked on. Each project has helped me develop different skills and tackle unique challenges.
          </p>
        </div>
        
        <div>
          {projects.map((project, index) => (
            <ProjectCard 
              key={project.title} 
              project={project} 
              index={index}
            />
          ))}
        </div>
        
        <div className="bg-gray-50 rounded-xl p-8 mt-12">
          <div className="text-center">
            <h3 className="text-xl font-bold text-gray-800 mb-4">More Projects Coming Soon</h3>
            <p className="text-gray-600">
              I'm constantly working on new projects to expand my portfolio and skillset. 
              Check back soon or follow my GitHub profile for updates!
            </p>
            <a 
              href="https://github.com/Saichand22" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="mt-4 inline-block text-blue-600 hover:underline"
            >
              Visit my GitHub profile
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Projects;