import React from 'react';
import { personalInfo } from '../data/data';
import { Github, Linkedin, Mail, Phone, ArrowDown } from 'lucide-react';

const Hero: React.FC = () => {
  const scrollToProjects = () => {
    const projectsSection = document.getElementById('projects');
    if (projectsSection) {
      projectsSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section 
      id="home" 
      className="relative min-h-screen flex items-center pt-20 bg-gradient-to-br from-blue-900 via-blue-700 to-blue-500 text-white overflow-hidden"
    >
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-full h-full bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgdmlld0JveD0iMCAwIDYwIDYwIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC40Ij48cGF0aCBkPSJNMzYgMzRjMCAxLjEtLjkgMi0yIDJzLTItLjktMi0yIC45LTIgMi0yIDIgLjkgMiAyem0tNCAyMnYtNGMwLTEuMS0uOS0yLTItMnMtMiAuOS0yIDJ2NGMwIDEuMS45IDIgMiAyczItLjkgMi0yem0xNi0xNmMxLjEgMCAyLS45IDItMnMtLjktMi0yLTItMiAuOS0yIDIgLjkgMiAyIDJ6TTE2IDM2VjIwYzAtMS4xLS45LTItMi0ycy0yIC45LTIgMnYxNmMwIDEuMS45IDIgMiAyczItLjkgMi0yem0zMC0xNmMxLjEgMCAyLS45IDItMnMtLjktMi0yLTItMiAuOS0yIDIgLjkgMiAyIDJ6TTQ2IDEwYzEuMSAwIDItLjkgMi0ycy0uOS0yLTItMi0yIC45LTIgMiAuOSAyIDIgMnptLjkgNDEuOWMtLjctLjctMS44LS43LTIuNSAwLS43LjctLjcgMS44IDAgMi41LjcuNyAxLjguNyAyLjUgMCAuNy0uNy43LTEuOSAwLTIuNXptLTMuOS01Yy0uNy0uNy0xLjgtLjctMi41IDAtLjcuNy0uNyAxLjggMCAyLjUuNy43IDEuOC43IDIuNSAwIC43LS43LjctMS45IDAtMi41ek0yMCAxMGMxLjEgMCAyLS45IDItMnMtLjktMi0yLTItMiAuOS0yIDIgLjkgMiAyIDJ6bTAtMThDOS0xLS44IDktLjggMjBzOS44IDIyIDIwLjggMjJTNDEgMzAuOSA0MSAyMCAzMS4yLTIgMjAtMnoiLz48L2c+PC9nPjwvc3ZnPg==')]"></div>
      </div>

      <div className="container mx-auto px-4 z-10">
        <div className="max-w-4xl mx-auto">
          <div className="flex flex-col md:flex-row items-center gap-8 mb-12">
            <div className="w-48 h-48 rounded-full overflow-hidden border-4 border-white shadow-xl">
              <img 
                src="https://media-hosting.imagekit.io/32896611a6f54cb7/profile%20picture.jpg?Expires=1840601541&Key-Pair-Id=K2ZIVPTIP2VGHC&Signature=ODWQx0DycvaGg~1wqQmWnY5mlXnKVCdBWvNNqqzw3UpIYCo9fh8rbQFbbP6d5-QJNWx2-S5yxPRWfnl~30jTWTpMTN9kngh3Mah9NCX53YBZrKyCLsv21~GdG~nJTr1qtGhi1jLwljgjFEwLQF-0Si8OjLdve-9-GrNuOwfABJe7Imn5l9kqCYJmsDvCI5i4D2cuBGXaQgf3-sLp2ZdkMUDTXDarIqwvcA6XwwvaAD~tMyjZtBFGiilzPrz3DWoikhXveDyat-pugb573Kf2k3UtDMOw4OW0VXt4Og~I0PJ47Ph8MADyrSWoSr6WXXkBMpgFvzpuzuhbqlTFFpv9GQ__" 
                alt="Bokka Sai Chand"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="text-center md:text-left">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4 opacity-0 animate-fade-in" style={{animationDelay: '0.3s', animationFillMode: 'forwards'}}>
                Hello, I'm <span className="text-blue-300">Sai Chand</span>
              </h1>
              <h2 className="text-xl md:text-2xl mb-6 text-blue-100 opacity-0 animate-fade-in" style={{animationDelay: '0.6s', animationFillMode: 'forwards'}}>
                Computer Science Engineering Student
              </h2>
              <p className="text-lg mb-8 max-w-2xl opacity-0 animate-fade-in" style={{animationDelay: '0.9s', animationFillMode: 'forwards'}}>
                I'm passionate about building impactful software and continuously expanding my skills in web development and software engineering.
              </p>
            </div>
          </div>
          
          <div className="flex flex-wrap justify-center gap-4 mb-8 opacity-0 animate-fade-in" style={{animationDelay: '1.2s', animationFillMode: 'forwards'}}>
            <a 
              href={personalInfo.github} 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center space-x-2 px-4 py-2 bg-white bg-opacity-10 hover:bg-opacity-20 rounded-md transition-all duration-300"
            >
              <Github size={18} />
              <span>GitHub</span>
            </a>
            <a 
              href={personalInfo.linkedin} 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center space-x-2 px-4 py-2 bg-white bg-opacity-10 hover:bg-opacity-20 rounded-md transition-all duration-300"
            >
              <Linkedin size={18} />
              <span>LinkedIn</span>
            </a>
            <a 
              href={`mailto:${personalInfo.email}`}
              className="flex items-center space-x-2 px-4 py-2 bg-white bg-opacity-10 hover:bg-opacity-20 rounded-md transition-all duration-300"
            >
              <Mail size={18} />
              <span>Email</span>
            </a>
          </div>
          
          <button 
            onClick={scrollToProjects}
            className="inline-flex items-center space-x-2 px-6 py-3 bg-white text-blue-700 font-medium rounded-md hover:bg-blue-50 transition-all duration-300 shadow-lg opacity-0 animate-fade-in mx-auto block"
            style={{animationDelay: '1.5s', animationFillMode: 'forwards'}}
          >
            <span>View My Work</span>
            <ArrowDown size={18} />
          </button>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <ArrowDown size={24} />
      </div>
    </section>
  );
};

export default Hero;