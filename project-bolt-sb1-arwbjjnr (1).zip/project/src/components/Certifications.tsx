import React from 'react';
import { certifications } from '../data/data';
import CertificationCard from './CertificationCard';

const Certifications: React.FC = () => {
  return (
    <section id="certifications" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">Certifications</h2>
          <div className="w-20 h-1 bg-blue-600 mx-auto mb-6"></div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            I believe in continuous learning and have earned certifications to expand my knowledge in various areas, particularly in AI and modern software development.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {certifications.map((certification) => (
            <CertificationCard 
              key={certification.title} 
              certification={certification} 
            />
          ))}
        </div>
        
        <div className="bg-blue-600 text-white rounded-xl p-8 mt-16">
          <div className="md:flex items-center">
            <div className="md:w-2/3 mb-6 md:mb-0">
              <h3 className="text-2xl font-bold mb-2">Continuous Learning</h3>
              <p className="text-blue-100">
                I'm constantly expanding my knowledge through online courses, certifications, and hands-on projects. My current focus is on deepening my understanding of AI applications and advanced web development techniques.
              </p>
            </div>
            <div className="md:w-1/3 md:pl-8 flex justify-center">
              <div className="w-24 h-24 bg-white bg-opacity-10 rounded-full flex items-center justify-center">
                <div className="text-4xl">🎓</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Certifications;