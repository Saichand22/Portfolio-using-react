import React from 'react';
import { Project } from '../types';
import { ExternalLink, Github } from 'lucide-react';

interface ProjectCardProps {
  project: Project;
  index: number;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ project, index }) => {
  const isEven = index % 2 === 0;

  return (
    <div className="flex flex-col md:flex-row items-center bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 mb-16">
      <div className={`md:w-1/2 h-64 md:h-auto order-1 ${isEven ? 'md:order-1' : 'md:order-2'}`}>
        <img 
          src={project.image} 
          alt={project.title} 
          className="w-full h-full object-cover"
        />
      </div>
      
      <div className={`md:w-1/2 p-8 order-2 ${isEven ? 'md:order-2' : 'md:order-1'}`}>
        <h3 className="text-2xl font-bold text-gray-800 mb-3">{project.title}</h3>
        
        <p className="text-gray-600 mb-6">
          {project.description}
        </p>
        
        <div className="mb-6">
          <h4 className="text-sm uppercase tracking-wider text-gray-500 mb-2">Technologies Used</h4>
          <div className="flex flex-wrap gap-2">
            {project.technologies.map(tech => (
              <span 
                key={tech} 
                className="px-3 py-1 bg-blue-100 text-blue-700 text-sm rounded-full"
              >
                {tech}
              </span>
            ))}
          </div>
        </div>
        
        <div className="flex space-x-4">
          <a 
            href={project.liveLink} 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center space-x-1 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors duration-300"
          >
            <ExternalLink size={16} />
            <span>Live Demo</span>
          </a>
          <a 
            href={project.githubLink} 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center space-x-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors duration-300"
          >
            <Github size={16} />
            <span>Code</span>
          </a>
        </div>
      </div>
    </div>
  );
};

export default ProjectCard;