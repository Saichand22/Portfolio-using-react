import React from 'react';
import { Certification } from '../types';
import { ExternalLink } from 'lucide-react';

interface CertificationCardProps {
  certification: Certification;
}

const CertificationCard: React.FC<CertificationCardProps> = ({ certification }) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transform transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
      <div className="p-6">
        <div className="flex justify-between items-start mb-4">
          <h3 className="text-xl font-bold text-gray-800">{certification.title}</h3>
          <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full">
            {certification.date}
          </span>
        </div>
        
        <p className="text-gray-600 mb-4">
          Issued by <span className="font-medium">{certification.issuer}</span>
        </p>
        
        <a 
          href={certification.certificateLink} 
          target="_blank" 
          rel="noopener noreferrer"
          className="flex items-center space-x-1 text-blue-600 hover:text-blue-800 transition-colors duration-300 mt-2"
        >
          <ExternalLink size={16} />
          <span>View Certificate</span>
        </a>
      </div>
    </div>
  );
};

export default CertificationCard;