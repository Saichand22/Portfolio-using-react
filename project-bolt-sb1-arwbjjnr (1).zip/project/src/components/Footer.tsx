import React from 'react';
import { personalInfo } from '../data/data';

const Footer: React.FC = () => {
  const year = new Date().getFullYear();
  
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-6 md:mb-0">
            <h2 className="text-2xl font-bold">Bokka Sai Chand</h2>
            <p className="text-gray-400 mt-2">Computer Science Engineering Student</p>
          </div>
          
          <div className="flex flex-col md:flex-row md:items-center space-y-4 md:space-y-0 md:space-x-8">
            <a 
              href="#home"
              className="text-gray-400 hover:text-white transition-colors duration-300"
            >
              Home
            </a>
            <a 
              href="#skills"
              className="text-gray-400 hover:text-white transition-colors duration-300"
            >
              Skills
            </a>
            <a 
              href="#projects"
              className="text-gray-400 hover:text-white transition-colors duration-300"
            >
              Projects
            </a>
            <a 
              href="#certifications"
              className="text-gray-400 hover:text-white transition-colors duration-300"
            >
              Certifications
            </a>
            <a 
              href="#education"
              className="text-gray-400 hover:text-white transition-colors duration-300"
            >
              Education
            </a>
            <a 
              href="#contact"
              className="text-gray-400 hover:text-white transition-colors duration-300"
            >
              Contact
            </a>
          </div>
        </div>
        
        <hr className="border-gray-800 my-8" />
        
        <div className="flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm mb-4 md:mb-0">
            &copy; {year} Bokka Sai Chand. All rights reserved.
          </p>
          
          <div>
            <a 
              href={personalInfo.resumeLink} 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-blue-400 hover:text-blue-300 transition-colors duration-300"
            >
              Download Resume
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;