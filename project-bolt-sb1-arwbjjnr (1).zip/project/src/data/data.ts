import { PersonalInfo, Project, Certification, Education, Skill } from '../types';
import { Code, Server, Database, Cloud } from 'lucide-react';

export const personalInfo: PersonalInfo = {
  name: "Bokka Sai Chand",
  title: "Computer Science Engineering Student",
  email: "saichand1974@gmail.com",
  phone: "+91-6304670347",
  github: "https://github.com/Saichand22",
  linkedin: "https://linkedin.com/in/b-sai-chand",
  resumeLink: "https://drive.google.com/file/d/15oNyMrDaLJwjc__21TIHAEBkQemmOFeE/view?usp=sharing"
};

export const skills: Skill[] = [
  { name: "C++", icon: "devicon-cplusplus-plain" },
  { name: "Java", icon: "devicon-java-plain" },
  { name: "C", icon: "devicon-c-plain" },
  { name: "HTML", icon: "devicon-html5-plain" },
  { name: "CSS", icon: "devicon-css3-plain" },
  { name: "JavaScript", icon: "devicon-javascript-plain" },
  { name: "MySQL", icon: "devicon-mysql-plain" },
  { name: "AWS", icon: "devicon-amazonwebservices-plain" },
  { name: "React", icon: "devicon-react-plain" },
  { name: "Node.js", icon: "devicon-nodejs-plain" },
  { name: "MongoDB", icon: "devicon-mongodb-plain" }
];

export const projects: Project[] = [
  {
    title: "Restaurant Order Taking Website",
    description: "Developed a dynamic restaurant order-taking website using HTML, CSS, and JavaScript. Focused on building a creative, user-friendly frontend interface that enables customers to place orders seamlessly. The project enhanced design creativity and strengthened frontend development skills, with attention to layout, user interaction, and responsive design.",
    technologies: ["HTML", "CSS", "JavaScript"],
    image: "https://images.pexels.com/photos/958545/pexels-photo-958545.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    liveLink: "https://moonlit-entremet-df3ba9.netlify.app",
    githubLink: "https://github.com/Saichand22"
  },
  {
    title: "Full Stack Home Rentals Application",
    description: "Developed a responsive home rentals platform using React.js, Redux for state management, Node.js, Express for backend services, and MongoDB as the database. Integrated JWT for secure user authentication and Material UI for a modern, intuitive design. Implemented key features such as property listings, booking functionality, and user dashboards. Ensured security with authentication and authorization mechanisms, providing a seamless user experience for both renters and property owners.",
    technologies: ["React.js", "Redux", "Node.js", "Express", "MongoDB", "JWT", "Material UI"],
    image: "https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    liveLink: "https://dainty-mochi-5bbad8.netlify.app",
    githubLink: "https://github.com/Saichand22"
  }
];

export const certifications: Certification[] = [
  {
    title: "Responsible & Safe AI System",
    issuer: "NPTEL",
    date: "2023",
    certificateLink: "https://drive.google.com/file/d/1fPgpnEblMG3A2QfNBSQ2TFoBiUqG5HCq/view?usp=sharing"
  },
  {
    title: "Build AI Apps with ChatGPT, Dall-E, GPT-4",
    issuer: "Coursera",
    date: "2023",
    certificateLink: "https://www.coursera.org/account/accomplishments/verify/SYU23VFQ7RJP"
  },
  {
    title: "Prompt Engineering for ChatGPT",
    issuer: "Coursera",
    date: "2023",
    certificateLink: "https://www.coursera.org/account/accomplishments/verify/5G6DK2FFYZLY"
  }
];

export const education: Education[] = [
  {
    degree: "Bachelor of Technology",
    institution: "Lovely Professional University",
    location: "Phagwara, India",
    period: "2022 - 2026",
    grade: "CGPA: 5.51"
  },
  {
    degree: "Board of Intermediate Education, AP",
    institution: "Tirumala Junior Kalasala",
    location: "Rajhamundry, India",
    period: "2020 - 2022",
    grade: "Marks: 879/1000"
  },
  {
    degree: "Secondary School Certificate",
    institution: "Tirumala Junior Kalasala",
    location: "Rajhamundry, India",
    period: "2019 - 2020",
    grade: "CGPA: 10/10"
  }
];